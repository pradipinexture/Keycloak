import{r as o,j as s,aJ as d}from"./index.0187f463.js";const f=o.forwardRef,c=f(({onChange:r,...a},e)=>s(d,{...a,ref:e,onChange:(w,t)=>r==null?void 0:r(t)}));c.displayName="TextArea";export{c as K};
