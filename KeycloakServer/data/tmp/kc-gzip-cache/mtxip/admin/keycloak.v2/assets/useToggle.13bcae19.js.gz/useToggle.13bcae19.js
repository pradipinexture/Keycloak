import{r as t}from"./index.0187f463.js";const o=t.useCallback,c=t.useState;function r(a=!1){const[s,e]=c(a),u=o(()=>e(l=>!l),[]);return[s,u,e]}export{r as u};
