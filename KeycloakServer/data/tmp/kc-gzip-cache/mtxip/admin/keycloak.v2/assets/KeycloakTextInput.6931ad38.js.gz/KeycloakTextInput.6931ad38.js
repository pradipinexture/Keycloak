import{r as o,j as s,aj as d}from"./index.0187f463.js";const f=o.forwardRef,p=f(({onChange:r,...t},a)=>s(d,{...t,ref:a,onChange:(n,e)=>r==null?void 0:r(e)}));p.displayName="TextInput";export{p as K};
